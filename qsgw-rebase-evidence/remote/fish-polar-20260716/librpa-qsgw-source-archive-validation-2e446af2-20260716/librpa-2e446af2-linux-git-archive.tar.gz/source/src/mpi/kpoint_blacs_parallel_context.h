#pragma once

#include <string>
#include <utility>
#include <vector>

#include "base_blacs.h"
#include "two_level_parallel_context.h"

namespace librpa_int
{

/*!
 * @brief Global-rank layout for the two-level k-point/BLACS decomposition.
 */
enum class KPointBlacsRankLayout
{
    CONTIGUOUS_BLACS,
    CONTIGUOUS_KPOINT
};

/*!
 * @brief Assignment order for k-points across k-point process groups.
 */
enum class KPointDistribution
{
    CYCLIC,
    CONTIGUOUS
};

/*!
 * @brief Shape of MPI processes assigned to k-point and BLACS parallelism.
 *
 * The total process count is nprocs_kpoint * nprocs_blacs.  The first level
 * creates k-point groups.  Inside each k-point group, nprocs_blacs processes
 * form the BLACS context used for NAO/ABF basis matrices.
 * favor_square_blacs_grid controls whether automatic resolution may prefer a
 * square-like BLACS process count and grid.
 *
 * Set either field to AUTO to let KPointBlacsParallelContext infer it from the
 * global communicator size and the number of k-points.  In the fully automatic
 * mode, the resolver prefers balanced k-point groups: if there is only one
 * k-point, all ranks are assigned to one BLACS context.
 */
struct KPointBlacsProcessShape : public TwoLevelProcessShape
{
    int &nprocs_kpoint;
    int &nprocs_blacs;
    bool favor_square_blacs_grid;

    KPointBlacsProcessShape(int nprocs_kpoint_in = AUTO, int nprocs_blacs_in = AUTO,
                            bool favor_square_blacs_grid_in = false);
    KPointBlacsProcessShape(const KPointBlacsProcessShape &other);
    KPointBlacsProcessShape &operator=(const KPointBlacsProcessShape &other);

    bool auto_kpoint() const noexcept { return auto_outer(); }
    bool auto_blacs() const noexcept { return auto_inner(); }
    std::string info() const;
};

/*!
 * @brief Resolve requested k-point/BLACS process shape against an MPI size.
 */
KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints);

//! Compatibility overload; matrix dimensions are validated but not used.
KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints,
                                                           int matrix_nrows, int matrix_ncols);

//! Square-matrix shorthand for resolve_kpoint_blacs_process_shape.
KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints,
                                                           int matrix_size);

/*!
 * @brief Choose a BLACS grid shaped for the input matrix dimensions.
 */
std::pair<int, int> choose_kpoint_blacs_grid(int nprocs_blacs, int matrix_nrows, int matrix_ncols,
                                             bool more_rows = true, bool favor_square_grid = false);

//! Square-matrix shorthand for choose_kpoint_blacs_grid.
std::pair<int, int> choose_kpoint_blacs_grid(int nprocs_blacs, int matrix_size,
                                             bool more_rows = true, bool favor_square_grid = false);

/*!
 * @brief Handler for k-point-level MPI communicators and basis-level BLACS.
 *
 * Global ranks are interpreted as a 2D process layout.  With the default
 * CONTIGUOUS_BLACS layout:
 *
 *   global_rank = kpoint_group_id * nprocs_blacs + blacs_rank
 *
 * With CONTIGUOUS_KPOINT layout:
 *
 *   global_rank = blacs_rank * nprocs_kpoint + kpoint_group_id
 *
 * This creates two useful communicators:
 * - comm_blacs_h: processes with the same kpoint_group_id; used by BLACS.
 * - comm_kpoint_h: processes with the same blacs_rank across k-point groups.
 *
 * Matrix dimensions are supplied when creating ArrayDesc objects, not stored in
 * the context.  K-points are assigned cyclically by default so ordered k-point
 * lists are spread across k-point groups.
 */
class KPointBlacsParallelContext : public TwoLevelParallelContext
{
private:
    KPointBlacsProcessShape requested_process_shape_;
    KPointBlacsProcessShape process_shape_;
    int n_kpoints_;
    int blacs_nprows_;
    int blacs_npcols_;
    CTXT_LAYOUT blacs_layout_;
    KPointBlacsRankLayout rank_layout_;
    KPointDistribution kpoint_distribution_;
    std::vector<int> kpoints_local_;

public:
    //! Communicator among k-point groups for the same BLACS rank.
    MpiCommHandler &comm_kpoint_h;
    //! Communicator inside one k-point group, used to create the BLACS context.
    MpiCommHandler &comm_blacs_h;
    //! BLACS context over comm_blacs_h.
    BlacsCtxtHandler blacs_h;

    KPointBlacsParallelContext();
    KPointBlacsParallelContext(
        const KPointBlacsProcessShape &process_shape, MPI_Comm comm_global, int n_kpoints,
        CTXT_LAYOUT blacs_layout = CTXT_LAYOUT::R,
        KPointBlacsRankLayout rank_layout = KPointBlacsRankLayout::CONTIGUOUS_BLACS,
        KPointDistribution kpoint_distribution = KPointDistribution::CYCLIC);
    ~KPointBlacsParallelContext() { finalize(); }

    KPointBlacsParallelContext(const KPointBlacsParallelContext &) = delete;
    KPointBlacsParallelContext &operator=(const KPointBlacsParallelContext &) = delete;

    void init(const KPointBlacsProcessShape &process_shape, MPI_Comm comm_global, int n_kpoints,
              CTXT_LAYOUT blacs_layout = CTXT_LAYOUT::R,
              KPointBlacsRankLayout rank_layout = KPointBlacsRankLayout::CONTIGUOUS_BLACS,
              KPointDistribution kpoint_distribution = KPointDistribution::CYCLIC);
    void finalize();

    bool is_initialized() const noexcept { return TwoLevelParallelContext::is_initialized(); }

    const KPointBlacsProcessShape &requested_process_shape() const noexcept
    {
        return requested_process_shape_;
    }
    const KPointBlacsProcessShape &process_shape() const noexcept { return process_shape_; }
    int n_kpoints() const noexcept { return n_kpoints_; }
    int kpoint_group_id() const noexcept { return outer_group_id(); }
    int blacs_rank() const noexcept { return inner_rank(); }
    int blacs_nprows() const noexcept { return blacs_nprows_; }
    int blacs_npcols() const noexcept { return blacs_npcols_; }
    KPointBlacsRankLayout rank_layout() const noexcept { return rank_layout_; }
    KPointDistribution kpoint_distribution() const noexcept { return kpoint_distribution_; }
    const std::vector<int> &kpoints_local() const noexcept { return kpoints_local_; }

    bool owns_kpoint(int ik) const;
    int kpoint_owner(int ik) const;
    //! Indices of an auxiliary real-space/vector list owned by this k-point group.
    std::vector<int> local_aux_indices(int n_items) const;
    //! Owner k-point group of an auxiliary real-space/vector-list index.
    int aux_index_owner(int item_index, int n_items) const;
    //! R-list indices owned by this k-point group.
    std::vector<int> local_R_indices(int n_R) const;
    //! Owner k-point group of an R-list index.
    int R_owner(int iR, int n_R) const;
    //! Global rank of the root process in the BLACS communicator that owns k-point ik.
    int kpoint_blacs_root_global_rank(int ik) const;
    ArrayDesc create_array_desc(int matrix_nrows, int matrix_ncols,
                                int mb = KPointBlacsProcessShape::AUTO,
                                int nb = KPointBlacsProcessShape::AUTO, int irsrc = 0,
                                int icsrc = 0) const;
    std::string info() const;
};

} /* end of namespace librpa_int */
