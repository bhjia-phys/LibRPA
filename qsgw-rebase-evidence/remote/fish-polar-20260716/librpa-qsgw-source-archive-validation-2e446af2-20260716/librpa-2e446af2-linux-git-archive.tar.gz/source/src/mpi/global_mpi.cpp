#include "global_mpi.h"

// Public API headers
#include "librpa_enums.h"

#include <stdexcept>
#include <iostream>

#include "../utils/error.h"
#include "base_mpi.h"

namespace librpa_int
{

namespace global
{

MPI_Comm mpi_comm_global;
MpiCommHandler mpi_comm_global_h;
int myid_global = 0;
int size_global = 1;

std::string procname(mpi_procname_uninit);

MPI_Comm mpi_comm_intra;
MpiCommHandler mpi_comm_intra_h;
int myid_intra = 0;
int size_intra = 1;

MPI_Comm mpi_comm_inter;
MpiCommHandler mpi_comm_inter_h;
int myid_inter = 0;
int size_inter = 1;

static bool mpi_initialized = false;

void init_global_mpi(MPI_Comm comm)
{
    int flag;
    MPI_Initialized(&flag);
    if (flag == 0)
    {
        throw LIBRPA_RUNTIME_ERROR("MPI_Init or MPI_Init_thread must be called before init_global_mpi");
    }
#ifdef LIBRPA_USE_LIBRI
    else
    {
        // Check thread support when LibRI is used
        // int provided = 0;
        // MPI_Query_thread(&provided);
        // if (provided < MPI_THREAD_MULTIPLE)
        //     throw LIBRPA_RUNTIME_ERROR(
        //         "LIBRPA_USE_LIBRI switched on, but MPI_Init_thread was called with thread support "
        //         "below MPI_THREAD_MULTIPLE");
    }
#endif

    mpi_comm_global = comm;
    // Initialize handlers of global MPI communicator
    mpi_comm_global_h.reset_comm(mpi_comm_global);
    mpi_comm_global_h.init();
    myid_global = mpi_comm_global_h.myid;
    size_global = mpi_comm_global_h.nprocs;
    procname = mpi_comm_global_h.procname;

    // Communicators for shared-memory operations
    // Set up inter-node and intra-node communicators under the global communicator
    flag = MPI_Comm_split_type(mpi_comm_global, MPI_COMM_TYPE_SHARED, 0, MPI_INFO_NULL, &mpi_comm_intra);
    if (flag != 0)
    {
        throw std::runtime_error(
            std::string(__FILE__) + ":" + std::to_string(__LINE__) + ":" + std::string(__FUNCTION__) + ": "
            "intra-node communicator creation failed");
    }
    mpi_comm_intra_h.reset_comm(mpi_comm_intra);
    mpi_comm_intra_h.init();
    myid_intra = mpi_comm_intra_h.myid;
    size_intra = mpi_comm_intra_h.nprocs;

    flag = MPI_Comm_split(mpi_comm_global, myid_intra, myid_global, &mpi_comm_inter);
    if (flag != 0)
    {
        throw std::runtime_error(
            std::string(__FILE__) + ":" + std::to_string(__LINE__) + ":" + std::string(__FUNCTION__) + ": "
            "inter-node communicator creation failed");
    }

    mpi_comm_inter_h.reset_comm(mpi_comm_inter);
    mpi_comm_inter_h.init();
    myid_inter = mpi_comm_inter_h.myid;
    size_inter = mpi_comm_inter_h.nprocs;

    mpi_initialized = true;
}

bool is_mpi_initialized()
{
    return mpi_initialized;
}

void finalize_global_mpi()
{
    // Not initialized, just return
    if (!is_mpi_initialized()) return;
    procname = mpi_procname_uninit;
    mpi_comm_global_h.reset_comm();
    mpi_comm_inter_h.reset_comm();
    mpi_comm_intra_h.reset_comm();
    MPI_Comm_free(&mpi_comm_intra);
    MPI_Comm_free(&mpi_comm_inter);

    mpi_initialized = false;
}

}

}
