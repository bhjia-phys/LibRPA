#include "../core/analycont.h"
#include "../utils/constants.h"
#include "../io/stl_io_helper.h"

#include <cassert>
#include "testutils.h"
#include <iostream>

using std::vector;
using std::cout;
using std::endl;
using namespace librpa_int;


static void initialize_1_over_x_minus_x0_data(int n, const cplxdb &x0, vector<cplxdb> &xs,
                                              vector<cplxdb> &data)
{
    xs.resize(n);
    data.resize(n);
    for (int i = 0; i < n; i++)
    {
        xs[i] = {0.0, static_cast<double>(i+1)};
        data[i] = -1.0 / (xs[i] - x0);
    }
}

void test_analycont_pade()
{
    int n = 6;
    // original function: y = -1 / (x - x0), x0 = {2.0, 2.0}
    const cplxdb x0 = {2.0, 2.0};
    std::vector<cplxdb> xs(n);
    std::vector<cplxdb> data(n);
    initialize_1_over_x_minus_x0_data(n, x0, xs, data);
    cout << "Input x: " << xs << endl;
    cout << "Input y: " << data << endl;

    librpa_int::AnalyContPade pade(n, xs, data);
    // std::cout << data << endl;
    const cplxdb test_x = {1.0, 1.0};
    const cplxdb ref = -1.0 / (test_x - x0);
    const cplxdb ref_deriv = 1.0 / ((test_x - x0) * (test_x - x0));
    cplxdb test_y = pade.get(test_x);
    cplxdb test_deriv = pade.get_derivative(test_x);
    cout << "Reference: "<< ref << endl;
    cout << "     Test: "<< test_y << endl;
    cout << "Reference derivative: "<< ref_deriv << endl;
    cout << "     Test derivative: "<< test_deriv << endl;
    assert(fequal(ref, test_y));
    assert(fequal(ref_deriv, test_deriv));
}

void test_get_spectfunc_acpade()
{
    int n = 6;
    // original function: y = -1 / (x - x0), x0 = {2.0, 2.0}
    const cplxdb x0 = {2.0, 2.0};
    std::vector<cplxdb> xs(n);
    std::vector<cplxdb> data(n);
    initialize_1_over_x_minus_x0_data(n, x0, xs, data);
    librpa_int::AnalyContPade pade(n, xs, data);

    vector<cplxdb> omegas(2);
    omegas[0] = {0.0, 0.0};
    omegas[1] = {2.0, 3.0};

    // assume e_ks = v_xc = v_exx = 0, and then use the function above, we have
    // A(w) = - 1 / PI * Im [ w + 1 / (w - 2 - 2i) ]^{-1}
    // and
    // A(w=0) = - 1 / PI * Im [-2 - 2i]
    // A(w=2+3i) = - 1 / PI * Im [2 + 2i]^{-1}
    vector<double> ref_sf(2);
    ref_sf[0] = 2.0 / PI;
    ref_sf[1] = 0.25 / PI;

    auto sf = librpa_int::get_specfunc(pade, omegas, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
    assert(fequal_array(2, sf.data(), ref_sf.data(), false));

    // same results if we have v_xc cancels e_ks and v_exx
    sf = librpa_int::get_specfunc(pade, omegas, 0.0, 1.0, 2.0, 1.0, 0.0, 0.0);
    assert(fequal_array(2, sf.data(), ref_sf.data(), false));

    // same results if we shift the omegas and e_ks by reference (2.0)
    omegas[0] = {2.0, -1.0};
    omegas[1] = {4.0, 2.0};
    sf = librpa_int::get_specfunc(pade, omegas, 2.0, 1.0 + 2.0, 2.0, 1.0, 1.0, 1.0);
    assert(fequal_array(2, sf.data(), ref_sf.data(), false));
}

void test_analycont_pade_source_data()
{
    constexpr int n = 8;
    constexpr int n_pars = 4;
    std::vector<cplxdb> xs(n);
    std::vector<cplxdb> data(n);
    initialize_1_over_x_minus_x0_data(n, {2.0, 2.0}, xs, data);

    librpa_int::AnalyContPade pade(n_pars, xs, data);
    const auto &source_xs = pade.get_source_xs();
    const auto &source_data = pade.get_source_data();
    assert(source_xs.size() == n_pars);
    assert(source_data.size() == n_pars);

    const int expected_indices[n_pars] = {0, 2, 4, 7};
    for (int i = 0; i != n_pars; ++i)
    {
        assert(source_xs[i] == xs[expected_indices[i]]);
        assert(source_data[i] == data[expected_indices[i]]);
    }
}

void test_analycont_pade_resample_imag_grid()
{
    constexpr int n = 6;
    const cplxdb x0 = {2.0, 2.0};
    std::vector<cplxdb> xs;
    std::vector<cplxdb> data;
    initialize_1_over_x_minus_x0_data(n, x0, xs, data);

    librpa_int::AnalyContPade original(n, xs, data);
    std::vector<cplxdb> xs_resampled = {
        {0.0, 0.5},
        {0.0, 1.5},
        {0.0, 3.0},
        {0.0, 6.0},
    };
    std::vector<cplxdb> data_resampled;
    data_resampled.reserve(xs_resampled.size());
    for (const auto &x: xs_resampled)
    {
        data_resampled.emplace_back(original.get(x));
    }

    librpa_int::AnalyContPade resampled(xs_resampled.size(), xs_resampled, data_resampled);
    const cplxdb test_x = {1.0, 1.0};
    const cplxdb ref = -1.0 / (test_x - x0);
    assert(fequal(ref, resampled.get(test_x)));
}

int main(int argc, char *argv[])
{
    test_analycont_pade();
    test_get_spectfunc_acpade();
    test_analycont_pade_source_data();
    test_analycont_pade_resample_imag_grid();
}
