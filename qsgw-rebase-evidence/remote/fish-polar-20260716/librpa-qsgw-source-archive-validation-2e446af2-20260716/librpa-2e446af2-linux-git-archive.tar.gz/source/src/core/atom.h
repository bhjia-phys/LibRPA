/*!
 @file atom.h
 @brief Utilies to handle atomic model and related data
 @date 2022-05-05 minyez created
 */
#ifndef ATOM_H
#define ATOM_H

#include <set>
#include <vector>
#include <utility>
#include <map>
#include <unordered_map>
#include <cstdint>
/* #include "../math/vector3.h" */
/* #include "../math/matrix3.h" */

#include "../utils/base_utility.h"

namespace librpa_int {

//! type of atom indices
typedef std::size_t atom_t;

template <typename T>
inline atom_t as_atom(T x) noexcept
{
    return static_cast<atom_t>(x);
}

//! atom-pair type. NOTE: may turn into a class?
typedef std::pair<atom_t, atom_t> atpair_t;

//! Hash function for atom pair in unordered mapping/set. It works for number of atoms < 2^{32}
struct atpair_hash
{
    std::size_t operator()(const atpair_t &p) const noexcept
    {
        return (static_cast<std::size_t>(p.first) << 32) | static_cast<std::uint32_t>(p.second);
    }
};

//! mapping from atom entries to data
template <typename T>
struct atom_mapping
{
    using non_t       = T;
    //! mapping between single atom and data
    using single_t    = std::unordered_map<atom_t, T>;
    //! mapping between atom pair and data
    using pair_t      = std::unordered_map<atpair_t, T, atpair_hash>;
    // //! mapping between tri-atom group and data
    // using tri_t       = std::map<std::pair<atom_t, atpair_t>, T>;
    //! mapping between atom pair and data. Nested map, old style
    using pair_t_old  = std::unordered_map<atom_t, std::unordered_map<atom_t, T>>;
    // //! mapping between tri-atom group and data. Nested map, old style
    // using tri_t_old   = std::unordered_map<atom_t, std::unordered_map<atom_t, std::unordered_map<atom_t, T>>>;
};

//! Alias of mapping from atom pair to data, with atom pair as key
template <typename T>
using ap_p_map = typename atom_mapping<T>::pair_t; // pair mapping

//! Alias of mapping from atom pair (old style, nested map) to data
template <typename T>
using ap_n_map = typename atom_mapping<T>::pair_t_old; // nested mapping

//! get atom indcies from a atom_mapping::single_t object (old style)
template <typename T>
std::vector<atom_t> get_atom(const std::unordered_map<atom_t, T> &adata) // work
/* vector<atom_t> get_atom(const typename atom_mapping<T>::single_t &adata) // not work */
{
    std::vector<atom_t> alist;
    for (const auto &a1: adata)
            alist.push_back(a1.first);
    return alist;
}

//! get atom pairs from a atom_mapping::pair_t object (old style)
template <typename T>
std::vector<atpair_t> get_atom_pair(const std::unordered_map<atom_t, std::unordered_map<atom_t, T>> &apdata) // work
/* vector<pair<atom_t, atom_t>> get_atom_pair(const typename atom_mapping<T>::pair_t &apdata) // not work */
{
    std::vector<atpair_t> apair;
    for (const auto &a1: apdata)
        for (const auto &a2: a1.second)
            apair.push_back({a1.first, a2.first});
    return apair;
}

//! get atom pairs from a atom_mapping::pair_t object
template <typename T>
std::vector<atpair_t> get_atom_pair(const std::unordered_map<atpair_t, T, atpair_hash> &apdata) // work
/* vector<pair<atom_t, atom_t>> get_atom_pair(const typename atom_mapping<T>::pair_t &apdata) // not work */
// FIXME: check this: https://en.cppreference.com/w/cpp/language/template_argument_deduction
{
    std::vector<atpair_t> apair;
    for (const auto &ap: apdata)
        apair.push_back(ap.first);
    return apair;
}

//! Get atom pair from number of atoms. The generated paris are in upper half if ordered_pair is false.
template <typename T>
std::vector<atpair_t> generate_atom_pair_from_nat(const T &nat, bool ordered_pair = false)
{
    std::vector<atpair_t> apair;
    for(T i=0; i!=nat; i++)
        for(T j = ordered_pair? 0 : i; j!=nat; j++)
            apair.push_back({i,j});
    return apair;
}

template <typename TA1, typename TA2>
std::pair<std::set<TA1>, std::set<TA2>> convert_IJset_to_Iset_Jset(std::set<std::pair<TA1, TA2>> IJset)
{
    std::set<TA1> Iset, Jset;
    for (const auto& IJ: IJset)
    {
        Iset.insert(IJ.first);
        Jset.insert(IJ.second);
    }
    return {Iset, Jset};
}

}

#endif // !ATOM_H
