#include "atomic_basis.h"

#include <algorithm>
#include <cassert>
#include <numeric>
#include <stdexcept>
#include <iostream>

#include "../utils/base_utility.h"
#include "../io/stl_io_helper.h"

namespace librpa_int {

bool same_species_basis_layout(const SpeciesBasisLayout &lhs,
                               const SpeciesBasisLayout &rhs)
{
    if (lhs.n_ao != rhs.n_ao)
    {
        return false;
    }
    if (lhs.is_shell_available() != rhs.is_shell_available())
    {
        return false;
    }
    return !lhs.is_shell_available() || lhs.l_shells == rhs.l_shells;
}

const SpeciesBasisLayout& get_symmetry_species_layout(
    const std::vector<SpeciesBasisLayout>& layouts,
    const int atom_type)
{
    if (atom_type < 0 || atom_type >= static_cast<int>(layouts.size()))
    {
        throw std::out_of_range("Atom type is out of range in symmetry species layout");
    }
    const auto& layout = layouts[static_cast<std::size_t>(atom_type)];
    if (!layout.is_shell_available())
    {
        throw std::runtime_error("Symmetry species layout is missing shell metadata");
    }
    return layout;
}

SpeciesBasisLayout species_basis_layout_from_atom(const AtomicBasis &basis,
                                                  const atom_t atom,
                                                  const int atom_type)
{
    SpeciesBasisLayout layout;
    layout.label = std::to_string(atom_type + 1);
    if (basis.has_l_shells())
    {
        layout.set(basis.get_l_shells(static_cast<int>(atom)));
    }
    else
    {
        layout.n_ao = static_cast<int>(basis.get_atom_nb(static_cast<int>(atom)));
    }
    return layout;
}

void condense_species_basis_layouts(const AtomicBasis &basis,
                                    const std::map<atom_t, int> &atom_to_type,
                                    std::map<int, SpeciesBasisLayout> &layouts)
{
    layouts.clear();
    if (!basis.initialized() || atom_to_type.empty())
    {
        return;
    }

    for (const auto &entry : atom_to_type)
    {
        const auto atom = entry.first;
        const int atom_type = entry.second;
        if (atom_type < 0 || atom >= basis.n_atoms)
        {
            throw std::runtime_error("Atomic basis shell metadata is inconsistent with atom types");
        }

        const auto layout = species_basis_layout_from_atom(basis, atom, atom_type);
        const auto inserted = layouts.emplace(atom_type, layout);
        if (!inserted.second && !same_species_basis_layout(inserted.first->second, layout))
        {
            throw std::runtime_error("Atomic basis shell metadata differs within one atom type");
        }
    }
}

bool type_layouts_have_shells(const std::map<int, SpeciesBasisLayout> &layouts)
{
    return !layouts.empty()
           && std::all_of(layouts.begin(), layouts.end(),
                          [](const auto &entry) {
                              return entry.second.is_shell_available();
                          });
}

std::vector<SpeciesBasisLayout> AtomicBasis::build_species_basis_layouts(
    const std::map<atom_t, int>& atom_to_type) const
{
    std::map<int, SpeciesBasisLayout> layouts_by_type;
    condense_species_basis_layouts(*this, atom_to_type, layouts_by_type);
    if (layouts_by_type.empty())
    {
        return {};
    }

    std::vector<SpeciesBasisLayout> layouts(
        static_cast<std::size_t>(layouts_by_type.rbegin()->first + 1));
    for (const auto& entry : layouts_by_type)
    {
        layouts[static_cast<std::size_t>(entry.first)] = entry.second;
    }
    return layouts;
}

void AtomicBasis::initialize()
{
    n_atoms = nbs_.size();

    if (n_atoms < 0)
        throw std::invalid_argument("empty basis is parsed");
    part_range_.resize(n_atoms + 1);
    part_range_[0] = 0;
    for (size_t i = 0; i < n_atoms; i++)
        part_range_[i+1] = part_range_[i] + nbs_[i];
    nb_total = part_range_[n_atoms];

    // compute local indices
    glo2iat_.resize(nb_total);
    glo2loc_.resize(nb_total);
    for (int I = 0; I < as_int(n_atoms); I++)
    {
        std::fill(glo2iat_.begin()+part_range_[I], glo2iat_.begin()+part_range_[I+1], I);
        std::iota(glo2loc_.begin()+part_range_[I], glo2loc_.begin()+part_range_[I+1], 0);
    }

    initialized_ = true;
}

AtomicBasis::AtomicBasis(const std::vector<int>& atom_species,
                         const std::map<int, std::size_t>& map_species_nb)
    : initialized_(false), nbs_(), part_range_(), glo2iat_(), glo2loc_(), l_shells_(), max_l_(-1)
{
    set(atom_species, map_species_nb);
    initialize();
}

AtomicBasis::AtomicBasis(const std::vector<std::size_t>& nbs)
    : initialized_(false), nbs_(nbs), part_range_(), l_shells_(), max_l_(-1), n_atoms(0), nb_total(0)
{
    initialize();
}

AtomicBasis::AtomicBasis(const std::map<size_t, std::size_t>& iatom_nbs)
    : initialized_(false), nbs_(), part_range_(), l_shells_(), max_l_(-1), n_atoms(0), nb_total(0)
{
    // sort atom index first
    // std::function<bool(const std::pair<std::size_t, std::size_t>&,
    //                    const std::pair<std::size_t, std::size_t>&)>
    set(iatom_nbs);
}

void AtomicBasis::set(const std::vector<std::size_t>& nbs)
{
    nbs_.clear();
    l_shells_.clear();
    max_l_ = -1;
    nbs_ = nbs;
    // std::cout << "nbs_ " << nbs_ << std::endl;
    initialize();
}

void AtomicBasis::set(const std::vector<int>& atom_species,
                      const std::map<int, std::size_t>& map_species_nb)
{
    nbs_.clear();
    l_shells_.clear();
    max_l_ = -1;
    for (const auto &atom: atom_species)
    {
        if (map_species_nb.count(atom))
            this->nbs_.push_back(map_species_nb.at(atom));
    }
    if (atom_species.size() != this->nbs_.size())
    {
        throw std::invalid_argument("missing nbs for some atom");
    }
    initialize();
}

void AtomicBasis::set(const std::map<std::size_t, std::size_t>& iatom_nbs)
{
    auto sortfn = [](const std::pair<std::size_t, std::size_t> &p1,
                     const std::pair<std::size_t, std::size_t> &p2)
                    { return p1.first < p2.first; };
    std::vector<std::pair<std::size_t, std::size_t>> v_ianb;
    for (const auto &ia_nb: iatom_nbs)
        v_ianb.push_back(ia_nb);
    std::sort(v_ianb.begin(), v_ianb.end(), sortfn);
    std::vector<std::size_t> nbs;
    nbs_.clear();
    l_shells_.clear();
    max_l_ = -1;
    for (const auto &nb: v_ianb)
        nbs_.push_back(nb.second);
    initialize();
}

void AtomicBasis::set_l_shells(const std::vector<std::vector<int>>& l_shells)
{
    if (l_shells.empty())
    {
        l_shells_.clear();
        max_l_ = -1;
        return;
    }
    if (!initialized_ || l_shells.size() != n_atoms)
    {
        throw std::invalid_argument("l-shell metadata is inconsistent with atomic basis");
    }
    int max_l = -1;
    for (std::size_t iat = 0; iat < l_shells.size(); ++iat)
    {
        std::size_t nb = 0;
        for (const int l : l_shells[iat])
        {
            if (l < 0)
            {
                throw std::invalid_argument("negative angular momentum in l-shell metadata");
            }
            max_l = std::max(max_l, l);
            nb += static_cast<std::size_t>(2 * l + 1);
        }
        if (nb != nbs_[iat])
        {
            throw std::invalid_argument("l-shell metadata dimension does not match atomic basis");
        }
    }
    l_shells_ = l_shells;
    max_l_ = max_l;
}

std::vector<std::size_t> AtomicBasis::get_global_indices(const int& i_atom) const
{
    std::vector<std::size_t> indices(this->nbs_[i_atom]);
    std::iota(indices.begin(), indices.end(), get_part_range()[i_atom]);
    return indices;
}

std::vector<std::pair<size_t, size_t>>
get_2d_mat_indices_atpair(const AtomicBasis &atbasis_r,
                          const AtomicBasis &atbasis_c,
                          const std::vector<atpair_t> &IJs,
                          const bool row_fast,
                          const bool sort_fast)
{
    std::vector<std::pair<size_t, size_t>> indices;
    size_t nelems = 0;

    // pre-compute the size of all indices to reserve enough space
    for (const auto &IJ: IJs)
    {
        nelems += get_pair_matrix_size(atbasis_r, IJ.first, atbasis_c, IJ.second);
    }
    indices.reserve(nelems);

    const auto append_indices = [&](const atpair_t& IJ) {
        const auto row_ids = atbasis_r.get_global_indices(IJ.first);
        const auto col_ids = atbasis_c.get_global_indices(IJ.second);

        if (row_fast)
        {
            for (const auto &c : col_ids)
                for (const auto &r : row_ids) indices.push_back({r, c});
        }
        else
        {
            for (const auto &r : row_ids)
                for (const auto &c : col_ids) indices.push_back({r, c});
        }
    };

    if (sort_fast)
    {
        // pre-sort the atom pairs to make index sorting easier
        std::vector<atpair_t> IJs_sorted = IJs;
        std::sort(IJs_sorted.begin(), IJs_sorted.end(), FastLess<atpair_t>{row_fast});

        for (const auto &IJ: IJs_sorted) append_indices(IJ);
        std::sort(indices.begin(), indices.end(), FastLess<gloid_ap_t>{row_fast});
    }
    else
    {
        for (const auto &IJ: IJs) append_indices(IJ);
    }

    return indices;
}

std::vector<size_t> get_1d_mat_indices_atpair(const AtomicBasis &atbasis_r,
                                              const AtomicBasis &atbasis_c,
                                              const std::vector<atpair_t> &IJs,
                                              const bool row_fast,
                                              const bool row_major,
                                              const bool sort_fast)
{
    const auto indices_2d = get_2d_mat_indices_atpair(atbasis_r, atbasis_c, IJs, row_fast, sort_fast);
    const auto indices_1d = flatten_2d_indices(indices_2d, atbasis_r.nb_total, atbasis_c.nb_total, row_major);
    return indices_1d;
}

// AtomicBasis atomic_basis_wfc;
// AtomicBasis atomic_basis_abf;

} // namespace librpa_int
