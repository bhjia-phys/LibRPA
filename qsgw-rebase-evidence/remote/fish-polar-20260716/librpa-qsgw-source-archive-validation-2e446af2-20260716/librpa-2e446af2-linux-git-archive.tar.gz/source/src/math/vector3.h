//==========================================================
//
//==========================================================
#ifndef VECTOR3_H
#define VECTOR3_H

// #ifdef _MCD_CHECK
//#include "../src_parallel/mcd.h"
// #endif

#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>

#include "mathtools.h"

namespace librpa_int {

template <class T>
class Vector3
{
public:
	T x;
	T y;
	T z;
	
	Vector3(const T &x1 = 0,const T &y1 = 0,const T &z1 = 0) :x(x1),y(y1),z(z1){};
	Vector3(const Vector3<T> &v) :x(v.x),y(v.y),z(v.z){};		// Peize Lin add 2018-07-16
	Vector3(const std::array<T, 3> &v) :x(v[0]),y(v[1]),z(v[2]){};		// Minye Zhang add 2026-06-06
	void set(const T &x1, const T &y1,const T &z1) { x = x1; y = y1; z = z1; }

	Vector3<T>& operator =(const Vector3<T> &u) { x=u.x; y=u.y; z=u.z;     return *this; }
    Vector3<T> &operator=(const std::array<T, 3> &u)
    {
        x = u[0];
        y = u[1];
        z = u[2];
        return *this;
    }
	Vector3<T>& operator+=(const Vector3<T> &u) { x+=u.x; y+=u.y; z+=u.z;  return *this; }
	Vector3<T>& operator-=(const Vector3<T> &u) { x-=u.x; y-=u.y; z-=u.z;  return *this; }
	Vector3<T>& operator*=(const Vector3<T> &u); 
	Vector3<T>& operator*=(const T &s)          { x*=s; y*=s; z*=s;        return *this; }
	Vector3<T>& operator/=(const Vector3<T> &u);
	Vector3<T>& operator/=(const T &s)          { x/=s; y/=s; z/=s;        return *this; }
	Vector3<T>  operator -() const              { return Vector3<T>(-x,-y,-z); }			// Peize Lin add 2017-01-10

	T norm_l1(void) const	{ return std::abs(x) + std::abs(y) + std::abs(z); }
	T norm2(void) const	{ return x*x + y*y + z*z; }
	T norm(void) const	{ return sqrt(norm2()); }
	Vector3<T>& normalize(void){ const T m=norm(); x/=m; y/=m; z/=m; return *this; }	// Peize Lin update return 2019-09-08
	Vector3<T>& reverse(void){ x=-x; y=-y; z=-z; return *this; }						// Peize Lin update return 2019-09-08
	std::array<T, 3> to_array() const { return {x, y, z}; }

	void print(void)const ;		// mohan add 2009-11-29
};

template <class T> Vector3<T> operator+( const Vector3<T> &u, const Vector3<T> &v ) { return Vector3<T>( u.x+v.x, u.y+v.y, u.z+v.z ); }
template <class T> Vector3<T> operator-( const Vector3<T> &u, const Vector3<T> &v ) { return Vector3<T>( u.x-v.x, u.y-v.y, u.z-v.z ); }
//u.v=(ux*vx)+(uy*vy)+(uz*vz)                                                     
template <class T> T          operator*( const Vector3<T> &u, const Vector3<T> &v ) { return ( u.x*v.x + u.y*v.y + u.z*v.z ); }
template <class T1, class T2, class TRet = T1> TRet operator*( const Vector3<T1> &u, const Vector3<T2> &v ) { return ( u.x*v.x + u.y*v.y + u.z*v.z ); }
template <class T> Vector3<T> operator*( const T &s,          const Vector3<T> &u ) { return Vector3<T>( u.x*s, u.y*s, u.z*s ); }
template <class T> Vector3<T> operator*( const Vector3<T> &u, const T &s          ) { return Vector3<T>( u.x*s, u.y*s, u.z*s ); } // mohan add 2009-5-10
template <class T> Vector3<T> operator/( const Vector3<T> &u, const T &s          ) { return Vector3<T>( u.x/s, u.y/s, u.z/s ); }
//u.v=(ux*vx)+(uy*vy)+(uz*vz)
template <class T> T          dot      ( const Vector3<T> &u, const Vector3<T> &v ) { return ( u.x*v.x + u.y*v.y + u.z*v.z ); }
template <class T> bool nearly_integer_vector(const Vector3<T> &u, const double tol = 1e-8)
{
	return nearly_integer(static_cast<double>(u.x), tol)
	    && nearly_integer(static_cast<double>(u.y), tol)
	    && nearly_integer(static_cast<double>(u.z), tol);
}
template <class T> Vector3<int> round_to_integer_vector(const Vector3<T> &u)
{
	return Vector3<int>(static_cast<int>(std::lround(static_cast<double>(u.x))),
	                    static_cast<int>(std::lround(static_cast<double>(u.y))),
	                    static_cast<int>(std::lround(static_cast<double>(u.z))));
}
inline Vector3<double> restrict_fractional_coordinate(const Vector3<double> &u, const double tol = 1e-8)
{
	const auto wrap = [tol](const double component) {
		const double wrapped = component - std::floor(component);
		return (std::abs(wrapped) < tol || std::abs(wrapped - 1.0) < tol) ? 0.0 : wrapped;
	};
	return Vector3<double>(wrap(u.x), wrap(u.y), wrap(u.z));
}
template <class T> Vector3<double> restrict_fractional_coordinate(const Vector3<T> &u, const double tol = 1e-8)
{
	return restrict_fractional_coordinate(Vector3<double>(static_cast<double>(u.x),
	                                                      static_cast<double>(u.y),
	                                                      static_cast<double>(u.z)),
	                                      tol);
}
// | i  j  k  |
// | ux uy uz |
// | vx vy vz |
// u.v=(uy*vz-uz*vy)i+(-ux*vz+uz*vx)j+(ux*vy-uy*vx)k
template <class T> Vector3<T> operator^(const Vector3<T> &u,const Vector3<T> &v)
{	
	return Vector3<T> ( u.y * v.z - u.z * v.y,
	                   -u.x * v.z + u.z * v.x,
	                    u.x * v.y - u.y * v.x);
}
// | i  j  k  |
// | ux uy uz |
// | vx vy vz |
// u.v=(uy*vz-uz*vy)i+(-ux*vz+uz*vx)j+(ux*vy-uy*vzx)k
template <class T> Vector3<T> cross(const Vector3<T> &u,const Vector3<T> &v)
{
	return Vector3<T> ( u.y * v.z - u.z * v.y,
	                   -u.x * v.z + u.z * v.x,
	                    u.x * v.y - u.y * v.x); 
}
//s = u.(v x w)
//template <class T> T TripleScalarProduct(Vector3<T> u, Vector3<T> v, Vector3<T> w)
//{
//	return T((u.x * (v.y * w.z - v.z * w.y)) +
//	         (u.y * (-v.x * w.z + v.z * w.x)) +
//	         (u.z * (v.x * w.y - v.y * w.x)));
//}

//whether m1 != m2
template <class T> bool operator !=(const Vector3<T> &u, const Vector3<T> &v){ return !(u == v); }
//whether u == v
template <class T> bool operator ==(const Vector3<T> &u, const Vector3<T> &v)
{
	if(u.x == v.x && u.y == v.y && u.z == v.z)
		return true;
	return false;
}

template <class T> void Vector3<T>::print(void)const
{
	std::cout.precision(5) ;
	std::cout << "(" << std::setw(10) << x << "," << std::setw(10) << y << ","
	<< std::setw(10) << z  << ")"  << std::endl ;
	return ;
}
template<class T> static std::ostream & operator << ( std::ostream &os, const Vector3<T> &u )
{
	os << "(" << std::setw(10) << u.x << "," << std::setw(10) << u.y << "," << std::setw(10) << u.z  << ")";
	return os;
}

}
#endif
