#include "kpoint_blacs_parallel_context.h"

#include <algorithm>
#include <cstdlib>
#include <sstream>

#include "../utils/error.h"

namespace librpa_int
{

namespace
{

static inline void check_positive(const char *name, int value)
{
    if (value <= 0) throw LIBRPA_RUNTIME_ERROR(std::string(name) + " must be positive");
}

static int min_contiguous_block_size(int global_size, int nprocs)
{
    check_positive("global_size", global_size);
    check_positive("nprocs", nprocs);
    return (global_size + nprocs - 1) / nprocs;
}

static TwoLevelRankLayout to_two_level_rank_layout(KPointBlacsRankLayout rank_layout)
{
    switch (rank_layout)
    {
        case KPointBlacsRankLayout::CONTIGUOUS_BLACS:
            return TwoLevelRankLayout::CONTIGUOUS_INNER;
        case KPointBlacsRankLayout::CONTIGUOUS_KPOINT:
            return TwoLevelRankLayout::CONTIGUOUS_OUTER;
    }
    throw LIBRPA_RUNTIME_ERROR("unknown k-point/BLACS rank layout");
}

static const char *rank_layout_name(KPointBlacsRankLayout rank_layout)
{
    switch (rank_layout)
    {
        case KPointBlacsRankLayout::CONTIGUOUS_BLACS:
            return "CONTIGUOUS_BLACS";
        case KPointBlacsRankLayout::CONTIGUOUS_KPOINT:
            return "CONTIGUOUS_KPOINT";
    }
    return "UNKNOWN";
}

static bool sequential_kpoint_distribution(KPointDistribution kpoint_distribution)
{
    switch (kpoint_distribution)
    {
        case KPointDistribution::CYCLIC:
            return false;
        case KPointDistribution::CONTIGUOUS:
            return true;
    }
    throw LIBRPA_RUNTIME_ERROR("unknown k-point distribution");
}

static const char *kpoint_distribution_name(KPointDistribution kpoint_distribution)
{
    switch (kpoint_distribution)
    {
        case KPointDistribution::CYCLIC:
            return "CYCLIC";
        case KPointDistribution::CONTIGUOUS:
            return "CONTIGUOUS";
    }
    return "UNKNOWN";
}

} /* end anonymous namespace */

KPointBlacsProcessShape::KPointBlacsProcessShape(int nprocs_kpoint_in, int nprocs_blacs_in,
                                                 bool favor_square_blacs_grid_in)
    : TwoLevelProcessShape(nprocs_kpoint_in, nprocs_blacs_in),
      nprocs_kpoint(nprocs_outer),
      nprocs_blacs(nprocs_inner),
      favor_square_blacs_grid(favor_square_blacs_grid_in)
{
}

KPointBlacsProcessShape::KPointBlacsProcessShape(const KPointBlacsProcessShape &other)
    : TwoLevelProcessShape(other.nprocs_kpoint, other.nprocs_blacs),
      nprocs_kpoint(nprocs_outer),
      nprocs_blacs(nprocs_inner),
      favor_square_blacs_grid(other.favor_square_blacs_grid)
{
}

KPointBlacsProcessShape &KPointBlacsProcessShape::operator=(
    const KPointBlacsProcessShape &other)
{
    nprocs_outer = other.nprocs_kpoint;
    nprocs_inner = other.nprocs_blacs;
    favor_square_blacs_grid = other.favor_square_blacs_grid;
    return *this;
}

std::string KPointBlacsProcessShape::info() const
{
    std::ostringstream oss;
    oss << "KPointBlacsProcessShape: "
        << "nprocs_kpoint ";
    if (auto_kpoint())
        oss << "AUTO";
    else
        oss << nprocs_kpoint;
    oss << " nprocs_blacs ";
    if (auto_blacs())
        oss << "AUTO";
    else
        oss << nprocs_blacs;
    oss << " favor_square_blacs_grid " << (favor_square_blacs_grid ? "T" : "F");
    return oss.str();
}

KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints)
{
    const auto resolved = resolve_two_level_process_shape(
        request, nprocs_global, n_kpoints, request.favor_square_blacs_grid);
    return {resolved.nprocs_outer, resolved.nprocs_inner, request.favor_square_blacs_grid};
}

KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints,
                                                           int matrix_nrows, int matrix_ncols)
{
    check_positive("matrix_nrows", matrix_nrows);
    check_positive("matrix_ncols", matrix_ncols);
    return resolve_kpoint_blacs_process_shape(request, nprocs_global, n_kpoints);
}

KPointBlacsProcessShape resolve_kpoint_blacs_process_shape(const KPointBlacsProcessShape &request,
                                                           int nprocs_global, int n_kpoints,
                                                           int matrix_size)
{
    check_positive("matrix_size", matrix_size);
    return resolve_kpoint_blacs_process_shape(request, nprocs_global, n_kpoints);
}

std::pair<int, int> choose_kpoint_blacs_grid(int nprocs_blacs, int matrix_nrows, int matrix_ncols,
                                             bool more_rows, bool favor_square_grid)
{
    check_positive("nprocs_blacs", nprocs_blacs);
    check_positive("matrix_nrows", matrix_nrows);
    check_positive("matrix_ncols", matrix_ncols);

    int best_nprows = 1;
    int best_npcols = nprocs_blacs;
    int best_overflow =
        std::max(0, best_nprows - matrix_nrows) + std::max(0, best_npcols - matrix_ncols);
    long long best_shape_mismatch = std::llabs(static_cast<long long>(best_nprows) * matrix_ncols -
                                               static_cast<long long>(best_npcols) * matrix_nrows);
    int best_balance = std::abs(best_nprows - best_npcols);
    int best_orientation_penalty = more_rows && best_nprows < best_npcols ? 1 : 0;
    if (!more_rows && best_npcols < best_nprows) best_orientation_penalty = 1;

    for (int nprows = 1; nprows <= nprocs_blacs; ++nprows)
    {
        if (nprocs_blacs % nprows != 0) continue;
        const int npcols = nprocs_blacs / nprows;
        const int overflow =
            std::max(0, nprows - matrix_nrows) + std::max(0, npcols - matrix_ncols);
        const long long shape_mismatch = std::llabs(static_cast<long long>(nprows) * matrix_ncols -
                                                    static_cast<long long>(npcols) * matrix_nrows);
        const int balance = std::abs(nprows - npcols);
        int orientation_penalty = more_rows && nprows < npcols ? 1 : 0;
        if (!more_rows && npcols < nprows) orientation_penalty = 1;

        bool is_better;
        if (favor_square_grid)
        {
            is_better = balance < best_balance ||
                        (balance == best_balance && overflow < best_overflow) ||
                        (balance == best_balance && overflow == best_overflow &&
                         shape_mismatch < best_shape_mismatch) ||
                        (balance == best_balance && overflow == best_overflow &&
                         shape_mismatch == best_shape_mismatch &&
                         orientation_penalty < best_orientation_penalty);
        }
        else
        {
            is_better = overflow < best_overflow ||
                        (overflow == best_overflow && shape_mismatch < best_shape_mismatch) ||
                        (overflow == best_overflow && shape_mismatch == best_shape_mismatch &&
                         balance < best_balance) ||
                        (overflow == best_overflow && shape_mismatch == best_shape_mismatch &&
                         balance == best_balance && orientation_penalty < best_orientation_penalty);
        }

        if (is_better)
        {
            best_nprows = nprows;
            best_npcols = npcols;
            best_overflow = overflow;
            best_shape_mismatch = shape_mismatch;
            best_balance = balance;
            best_orientation_penalty = orientation_penalty;
        }
    }

    return {best_nprows, best_npcols};
}

std::pair<int, int> choose_kpoint_blacs_grid(int nprocs_blacs, int matrix_size, bool more_rows,
                                             bool favor_square_grid)
{
    return choose_kpoint_blacs_grid(nprocs_blacs, matrix_size, matrix_size, more_rows,
                                    favor_square_grid);
}

KPointBlacsParallelContext::KPointBlacsParallelContext()
    : TwoLevelParallelContext(),
      requested_process_shape_(),
      process_shape_(),
      n_kpoints_(0),
      blacs_nprows_(0),
      blacs_npcols_(0),
      blacs_layout_(CTXT_LAYOUT::R),
      rank_layout_(KPointBlacsRankLayout::CONTIGUOUS_BLACS),
      kpoint_distribution_(KPointDistribution::CYCLIC),
      kpoints_local_(),
      comm_kpoint_h(comm_outer_h),
      comm_blacs_h(comm_inner_h),
      blacs_h()
{
}

KPointBlacsParallelContext::KPointBlacsParallelContext(const KPointBlacsProcessShape &process_shape,
                                                       MPI_Comm comm_global, int n_kpoints,
                                                       CTXT_LAYOUT blacs_layout,
                                                       KPointBlacsRankLayout rank_layout,
                                                       KPointDistribution kpoint_distribution)
    : KPointBlacsParallelContext()
{
    init(process_shape, comm_global, n_kpoints, blacs_layout, rank_layout, kpoint_distribution);
}

void KPointBlacsParallelContext::init(const KPointBlacsProcessShape &process_shape,
                                      MPI_Comm comm_global, int n_kpoints, CTXT_LAYOUT blacs_layout,
                                      KPointBlacsRankLayout rank_layout,
                                      KPointDistribution kpoint_distribution)
{
    if (is_initialized()) finalize();

    requested_process_shape_ = process_shape;
    n_kpoints_ = n_kpoints;
    blacs_layout_ = blacs_layout;
    rank_layout_ = rank_layout;
    kpoint_distribution_ = kpoint_distribution;

    MpiCommHandler comm_global_probe(comm_global, true);
    process_shape_ =
        resolve_kpoint_blacs_process_shape(process_shape, comm_global_probe.nprocs, n_kpoints_);
    // global::ofs_myid << "process_shape_: " << process_shape_.nprocs_kpoint << " " << process_shape_.nprocs_blacs << std::endl;

    TwoLevelParallelContext::init(process_shape_, comm_global,
                                  to_two_level_rank_layout(rank_layout_));

    blacs_h.reset_comm(comm_blacs_h.comm, true);
    const auto blacs_grid =
        choose_kpoint_blacs_grid(process_shape_.nprocs_blacs, process_shape_.nprocs_blacs, true,
                                 process_shape_.favor_square_blacs_grid);
    blacs_nprows_ = blacs_grid.first;
    blacs_npcols_ = blacs_grid.second;
    blacs_h.set_grid(blacs_nprows_, blacs_npcols_, blacs_layout_);

    kpoints_local_ = dispatcher(0, n_kpoints_, kpoint_group_id(), process_shape_.nprocs_kpoint,
                                sequential_kpoint_distribution(kpoint_distribution_));
}

void KPointBlacsParallelContext::finalize()
{
    if (!is_initialized()) return;

    blacs_h.reset_comm();
    TwoLevelParallelContext::finalize();

    process_shape_ = {};
    n_kpoints_ = 0;
    blacs_nprows_ = 0;
    blacs_npcols_ = 0;
    rank_layout_ = KPointBlacsRankLayout::CONTIGUOUS_BLACS;
    kpoint_distribution_ = KPointDistribution::CYCLIC;
    kpoints_local_.clear();
}

bool KPointBlacsParallelContext::owns_kpoint(int ik) const
{
    return std::find(kpoints_local_.begin(), kpoints_local_.end(), ik) != kpoints_local_.end();
}

int KPointBlacsParallelContext::kpoint_owner(int ik) const
{
    if (ik < 0 || ik >= n_kpoints_) throw LIBRPA_RUNTIME_ERROR("k-point index out of range");

    for (int group_id = 0; group_id < process_shape_.nprocs_kpoint; ++group_id)
    {
        const auto kpoints = dispatcher(0, n_kpoints_, group_id, process_shape_.nprocs_kpoint,
                                        sequential_kpoint_distribution(kpoint_distribution_));
        if (std::find(kpoints.begin(), kpoints.end(), ik) != kpoints.end()) return group_id;
    }
    throw LIBRPA_RUNTIME_ERROR("failed to find k-point owner");
}

std::vector<int> KPointBlacsParallelContext::local_aux_indices(int n_items) const
{
    if (!is_initialized()) throw LIBRPA_RUNTIME_ERROR("KPointBlacsParallelContext not initialized");
    if (n_items < 0) throw LIBRPA_RUNTIME_ERROR("number of auxiliary indices must be non-negative");
    if (n_items == 0) return {};

    // The auxiliary list is distributed along comm_kpoint_h.  Groups that own
    // more k/q-points receive fewer auxiliary items, keeping the product of
    // local q-work and local R-work roughly balanced.
    return dispatcher_balanced(0, n_items, static_cast<int>(kpoints_local_.size()), true,
                               comm_kpoint_h.comm);
}

int KPointBlacsParallelContext::aux_index_owner(int item_index, int n_items) const
{
    if (!is_initialized()) throw LIBRPA_RUNTIME_ERROR("KPointBlacsParallelContext not initialized");
    if (n_items < 0) throw LIBRPA_RUNTIME_ERROR("number of auxiliary indices must be non-negative");
    if (item_index < 0 || item_index >= n_items)
        throw LIBRPA_RUNTIME_ERROR("auxiliary index out of range");

    std::vector<int> weights(process_shape_.nprocs_kpoint, 0);
    const int weight_this = static_cast<int>(kpoints_local_.size());
    MPI_Allgather(&weight_this, 1, mpi_datatype<int>::value, weights.data(), 1,
                  mpi_datatype<int>::value, comm_kpoint_h.comm);

    for (int group_id = 0; group_id != process_shape_.nprocs_kpoint; ++group_id)
    {
        const auto indices = dispatcher_balanced(0, n_items, weights, group_id, true);
        if (std::find(indices.cbegin(), indices.cend(), item_index) != indices.cend())
            return group_id;
    }
    throw LIBRPA_RUNTIME_ERROR("failed to find auxiliary index owner");
}

std::vector<int> KPointBlacsParallelContext::local_R_indices(int n_R) const
{
    return local_aux_indices(n_R);
}

int KPointBlacsParallelContext::R_owner(int iR, int n_R) const
{
    return aux_index_owner(iR, n_R);
}

int KPointBlacsParallelContext::kpoint_blacs_root_global_rank(int ik) const
{
    if (!is_initialized()) throw LIBRPA_RUNTIME_ERROR("KPointBlacsParallelContext not initialized");

    const int kpoint_group_id = kpoint_owner(ik);
    return two_level_global_rank(process_shape_, to_two_level_rank_layout(rank_layout_),
                                 kpoint_group_id, 0);
}

ArrayDesc KPointBlacsParallelContext::create_array_desc(int matrix_nrows, int matrix_ncols, int mb,
                                                        int nb, int irsrc, int icsrc) const
{
    if (!is_initialized()) throw LIBRPA_RUNTIME_ERROR("KPointBlacsParallelContext not initialized");
    check_positive("matrix_nrows", matrix_nrows);
    check_positive("matrix_ncols", matrix_ncols);
    if (mb < 0 || nb < 0) throw LIBRPA_RUNTIME_ERROR("BLACS block sizes must be non-negative");

    const int mb_eff = mb == KPointBlacsProcessShape::AUTO
                           ? min_contiguous_block_size(matrix_nrows, blacs_h.nprows)
                           : mb;
    const int nb_eff = nb == KPointBlacsProcessShape::AUTO
                           ? min_contiguous_block_size(matrix_ncols, blacs_h.npcols)
                           : nb;
    check_positive("mb", mb_eff);
    check_positive("nb", nb_eff);

    ArrayDesc desc(blacs_h);
    desc.init(matrix_nrows, matrix_ncols, mb_eff, nb_eff, irsrc, icsrc);
    return desc;
}

std::string KPointBlacsParallelContext::info() const
{
    std::ostringstream oss;
    oss << "KPointBlacsParallelContext: "
        << "initialized " << (is_initialized() ? "T" : "F") << " "
        << "process_shape [" << process_shape_.info() << "] "
        << "kpoint_group_id " << kpoint_group_id() << " "
        << "blacs_rank " << blacs_rank() << " "
        << "n_kpoints " << n_kpoints_ << " "
        << "rank_layout " << rank_layout_name(rank_layout_) << " "
        << "kpoint_distribution " << kpoint_distribution_name(kpoint_distribution_) << " "
        << "blacs_grid (" << blacs_nprows_ << "," << blacs_npcols_ << ")";
    return oss.str();
}

} /* end of namespace librpa_int */
