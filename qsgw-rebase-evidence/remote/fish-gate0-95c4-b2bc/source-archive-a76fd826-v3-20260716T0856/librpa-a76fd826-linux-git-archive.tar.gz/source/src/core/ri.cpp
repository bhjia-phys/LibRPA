#include "ri.h"

#include <memory.h>

// #include "../math/utils_matrix_mpi.h"
// #include "../math/matrix.h"
// #include "../mpi/global_mpi.h"
// #include "params.h"
// #include "pbc.h"

namespace librpa_int
{

// int n_irk_points;
// int natom;
// int ncell;
// std::vector<Vector3_Order<double>> irk_points;
// map<Vector3_Order<double>, double> irk_weight;
// map<atom_t, size_t> atom_nw;
// map<atom_t, size_t> atom_mu;
// map<atom_t, size_t> atom_nw_loc;
// map<atom_t, size_t> atom_mu_loc;
// vector<size_t> atom_mu_part_range;
// int N_all_mu;
// 
// vector<atpair_t> tot_atpair;
// vector<atpair_t> local_atpair;
// vector<atpair_t> tot_atpair_ordered;

void Cs_LRI::clear()
{
    this->data_IJR.clear();
    this->data_libri.clear();
}

size_t Cs_LRI::n_keys() const
{
    size_t nk = 0;
    if (this->use_libri)
    {
        for (const auto &I_JR_data: this->data_libri)
        {
            nk += I_JR_data.second.size();
        }
    }
    else
    {
        for (const auto &IJR_data: this->data_IJR)
        {
            for (const auto &JR_data: IJR_data.second)
            {
                nk += JR_data.second.size();
            }
        }
    }
    return nk;
}

size_t Cs_LRI::n_data_bytes() const
{
    size_t nb = 0;
    if (this->use_libri)
    {
        for (const auto &I_JR_data: this->data_libri)
        {
            for (const auto &JR_data: I_JR_data.second)
            {
                nb += JR_data.second.data->size();
            }
        }
    }
    else
    {
        for (const auto &IJR_data: this->data_IJR)
        {
            for (const auto &JR_data: IJR_data.second)
            {
                for (const auto &R_data: JR_data.second)
                {
                    nb += R_data.second->size;
                }
            }
        }
    }
    return nb;
}

// Cs_LRI Cs_data;
void Cs_LRI_clx::clear()
{
    this->data_IJR.clear();
    this->data_libri.clear();
}

// atpair_k_cplx_mat_t Vq;
// atpair_k_cplx_mat_t Vq_cut;
// map<Vector3_Order<double>, ComplexMatrix> Vq_block_loc;
// map<Vector3_Order<double>, ComplexMatrix> Vq_cut_block_loc;

// int atom_iw_loc2glo(const int &atom_index, const int &iw_lcoal)
// {
//     int nb = 0;
//     for (int ia = 0; ia != atom_index; ia++)
//         nb += atom_nw[ia];
//     return iw_lcoal + nb;
// }

// int atom_mu_loc2glo(const int &atom_index, const int &mu_lcoal)
// {
//     // int nb = 0;
//     // for (int ia = 0; ia != atom_index; ia++)
//     //     nb += atom_mu[ia];
//     // return mu_lcoal + nb;
//     return atom_mu_part_range[atom_index]+mu_lcoal;
// }

// int atom_mu_glo2loc(const int &glo_index, int &mu_index)
// {
//     for(int I=0;I!=atom_mu.size();I++)
//     {
//         if((mu_index=glo_index-atom_mu_part_range[I])<atom_mu[I])
//             return I;
//     }
//     throw invalid_argument("invalid glo_index");
// }

// vector<int> get_part_range()
// {
//     vector<int> part_range;
//     part_range.resize(atom_mu.size());
//     part_range[0] = 0;
//
//     int count_range = 0;
//     for (int Mu = 0; Mu != atom_mu.size() - 1; Mu++)
//     {
//         count_range += atom_mu[Mu];
//         part_range[Mu + 1] = count_range;
//     }
//     return part_range;
// }

matrix reshape_Cs(size_t n1, size_t n2, size_t n3, const std::shared_ptr<matrix> &Csmat) //(n1*n2,n3) -> (n2,n1*n3)
{
    const auto length = sizeof(double) * n3;
    const auto n13 = n1 * n3;
    const double *m_ptr = (*Csmat).c;
    matrix m_new(n2, n1 * n3, false);
    for (size_t i1 = 0; i1 != n1; ++i1)
    {
        double *m_new_ptr = m_new.c + i1 * n3;
        for (size_t i2 = 0; i2 != n2; ++i2, m_ptr += n3, m_new_ptr += n13)
            memcpy(m_new_ptr, m_ptr, length);
    }
    return m_new;
}

matrix reshape_mat(const size_t n1, const size_t n2, const size_t n3, const matrix &mat) //(n1,n2*n3) -> (n2,n1*n3)
{
    const auto length = sizeof(double) * n3;
    const auto n13 = n1 * n3;
    const double *m_ptr = mat.c;
    matrix m_new(n2, n1 * n3, false);
    for (size_t i1 = 0; i1 != n1; ++i1)
    {
        double *m_new_ptr = m_new.c + i1 * n3;
        for (size_t i2 = 0; i2 != n2; ++i2, m_ptr += n3, m_new_ptr += n13)
            memcpy(m_new_ptr, m_ptr, length);
    }
    return m_new;
}

matrix reshape_mat_21(const size_t n1, const size_t n2, const size_t n3, const matrix &mat) //(n1,n2*n3) -> (n1*n2,n3)
{
    const auto length = sizeof(double) * n1 * n2 * n3;
    // const auto n13 = n1 * n2 * n3;
    const double *m_ptr = mat.c;
    matrix m_new(n1 * n2, n3, false);
    double *m_new_ptr = m_new.c;
    memcpy(m_new_ptr, m_ptr, length);
    return m_new;
}

// void allreduce_atp_aux()
// {
//     using global::mpi_comm_global;
//     using global::mpi_comm_global_h;
// 
//     if (Cs_data.use_libri)
//     {
//         return;
//     }
// 
//     auto & Cs= Cs_data.data_IJR;
// 
//     for(int I=0;I!=natom;I++)
//         for(int J=0;J!=natom;J++)
//         {
//             auto nbasI=atom_nw[I];
//             auto nbasJ=atom_nw[J];
//             auto nauxI=atom_mu[I];
//             int cs_size=nbasI*nbasJ*nauxI;
// 
//             int Rsize=Cs[I][J].size();
//             int loc_count=3* Rsize;
// 
//             std::vector<int> send_R_data;
//             std::vector<int> all_R_counts(mpi_comm_global_h.nprocs, 0);
// 
//             all_R_counts[mpi_comm_global_h.myid] = loc_count;
// 
//             for (const auto& Rp : Cs[I][J]) 
//             {   
//                 auto R=Rp.first;
//                 // if(I==0 && J==0)
//                 //     librpa_int::global::lib_printf(" send R  Cs  myid : %d   I: %d, J: %d, R:(%d, %d, %d)\n",mpi_comm_global_h.myid, I,J,R.x,R.y,R.z);
//                 send_R_data.push_back(Rp.first.x);
//                 send_R_data.push_back(Rp.first.y);
//                 send_R_data.push_back(Rp.first.z);
//             }
//             MPI_Allgather(&loc_count, 1, MPI_INT, all_R_counts.data(), 1, MPI_INT, mpi_comm_global);
//             std::vector<int> displs(mpi_comm_global_h.nprocs);
//             int total_R_count = 0;
//             for (int i = 0; i < mpi_comm_global_h.nprocs; ++i) {
//                 displs[i] = total_R_count;
//                 total_R_count +=  all_R_counts[i];
//             }
//             std::vector<int> all_R_data(total_R_count);
// 
//             MPI_Allgatherv(send_R_data.data(), loc_count, MPI_INT, all_R_data.data(), all_R_counts.data(), displs.data(), MPI_INT, mpi_comm_global);
//             
//             int nR=total_R_count/3;
//             for(int iR=0;iR!=nR;iR++)
//             {
//                 Vector3_Order<int> Rv(all_R_data[iR*3],all_R_data[iR*3+1],all_R_data[iR*3+2]);
//                 // if(I==0 && J==0)
//                 //     librpa_int::global::lib_printf(" Rv  Cs  myid : %d   I: %d, J: %d, R:(%d, %d, %d)\n",mpi_comm_global_h.myid, I,J,Rv.x,Rv.y,Rv.z);
//                 shared_ptr<matrix> cs_ptr = make_shared<matrix>();
//                 cs_ptr->create(nbasI*nbasJ, nauxI);
//                 matrix loc_cs(nbasI*nbasJ, nauxI);
//                 if(Cs[I][J].count(Rv))
//                     memcpy(loc_cs.c,(*Cs[I][J].at(Rv)).c,sizeof(double)*cs_size);
//                 allreduce_matrix(loc_cs,(*cs_ptr),mpi_comm_global_h.comm);
//                 if(!Cs[I][J].count(Rv))
//                     Cs[I][J][Rv] = cs_ptr;
//             }
//         }
// }

// void allreduce_2D_coulomb_to_atompair(map<Vector3_Order<double>, ComplexMatrix> &Vq_loc, atpair_k_cplx_mat_t &coulomb_mat,double threshold )
// {
//     using global::mpi_comm_global_h;
//     using global::lib_printf;
// 
//     lib_printf("Begin allreduce_2D_coulomb_to_atompair!\n");
// 
//     map<Vector3_Order<double>, ComplexMatrix> Vq_glo;
//     for(auto &qvec:klist_coul)
//     {
//         Vq_glo[qvec].create(N_all_mu,N_all_mu);
//         if(!Vq_block_loc.count(qvec))
//         {
//             Vq_block_loc[qvec].create(N_all_mu, N_all_mu);
//         }
//         
//         librpa_int::allreduce_ComplexMatrix(Vq_block_loc[qvec],Vq_glo[qvec],mpi_comm_global_h.comm);
//         // print_complex_matrix("vq_glo", Vq_glo[qvec]);
//     }
//     size_t vq_save = 0;
//     size_t vq_discard = 0;
//     for (auto &vf_p : Vq_glo)
//     {
//         auto qvec = vf_p.first;
//         // cout << "Qvec:" << qvec << endl;
//         
//         for (int I = 0; I != atom_mu.size(); I++)
//             for (int J = 0; J != atom_mu.size(); J++)
//             {
//                 if (I > J)
//                     continue;
//                 shared_ptr<ComplexMatrix> vq_ptr = make_shared<ComplexMatrix>();
//                 vq_ptr->create(atom_mu[I], atom_mu[J]);
//                 // vq_ptr_tran->create(atom_mu[J],atom_mu[I]);
//                 // cout << "I J: " << I << "  " << J << "   mu,nu: " << atom_mu[I] << "  " << atom_mu[J] << endl;
//                 for (int i_mu = 0; i_mu != atom_mu[I]; i_mu++)
//                 {
// 
//                     for (int i_nu = 0; i_nu != atom_mu[J]; i_nu++)
//                     {
//                         (*vq_ptr)(i_mu, i_nu) = vf_p.second(atom_mu_loc2glo(I, i_mu), atom_mu_loc2glo(J, i_nu));
//                     }
//                 }
// 
//                 // if (I == J)
//                 // {
//                 //     (*vq_ptr).set_as_identity_matrix();
//                 // }
// 
//                 if ((*vq_ptr).real().absmax() >= threshold)
//                 {
//                     coulomb_mat[I][J][qvec] = vq_ptr;
//                     vq_save++;
//                 }
//                 else
//                 {
//                     vq_discard++;
//                 }
//             }
//     }
// 
//     lib_printf("End allreduce_2D_coulomb_to_atompair!\n");
// }

// void allreduce_atp_coulomb( atpair_k_cplx_mat_t &coulomb_mat )
// {
//     using global::mpi_comm_global;
//     using global::mpi_comm_global_h;
//     using global::lib_printf;
// 
//     printf("Begin allreduce_atp_coulomb!\n");
//     // mpi_comm_world_h.barrier();
//     map<Vector3_Order<double>, ComplexMatrix> Vq_glo;
//     for(auto &qvec:klist_coul)
//     {
//         for(int I=0;I!=atom_mu.size();I++)
//         {
//             for(int J=I;J!=atom_mu.size();J++)
//             {
//                 shared_ptr<ComplexMatrix> vq_recv_ptr = make_shared<ComplexMatrix>();
//                 vq_recv_ptr->create(atom_mu[I], atom_mu[J]);
//                 ComplexMatrix tmp_send(atom_mu[I], atom_mu[J]);
//                 // ComplexMatrix tmp_recv(atom_mu[I], atom_mu[J]);
//                 if(coulomb_mat[I][J].count(qvec)!=0)
//                     tmp_send=*coulomb_mat.at(I).at(J).at(qvec);
//                     
//                 printf("I: %d, J: %d, mu:%d, nu:%d, myid: %d\n",I,J,atom_mu[I], atom_mu[J],mpi_comm_global_h.myid);
//                 librpa_int::allreduce_ComplexMatrix(tmp_send,*vq_recv_ptr,mpi_comm_global_h.comm);
//                 if(coulomb_mat[I][J].count(qvec)==0)
//                     coulomb_mat[I][J][qvec]=vq_recv_ptr;
//                 printf("end I: %d, J: %d,  myid: %d\n",I,J,mpi_comm_global_h.myid);
//                 
//                 
//                 // coulomb_mat[I][J][qvec]=vq_recv_ptr;
//                     
//             }
//         }
//         
//     }
// 
//     printf("End allreduce_atp_coulomb!\n");
//     // mpi_comm_world_h.barrier();
// }

}
