#include <cassert>
#include <stdexcept>

#include "../mpi/base_mpi.h"
#include "testutils.h"

using namespace librpa_int;

int myid_global;
int size_global;

void test_dispatcher_1d()
{
    const int myid = get_mpi_rank(MPI_COMM_WORLD);
    const int size = get_mpi_size(MPI_COMM_WORLD);

    int n;
    // single index dispatcher
    // balanced sequential case
    //   proc 0: 0, 1, 2
    //   proc 1: 3, 4, 5
    //   proc 2: 6, 7, 8
    //   proc 3: 9, 10, 11
    auto ilist = dispatcher(0, 12, myid, size, true);
    n = ilist.size();
    /* for (auto &id: ilist) */
    /*     printf("myid = %d, id = %u\n", myid, id); */
    assert(ilist.size() == 3);
    for (int i = 0; i != n; i++) assert(ilist[i] == myid * 3 + i);

    // balanced non-sequential case
    //   proc 0: 0, 4, 8
    //   proc 1: 1, 5, 9
    //   proc 2: 2, 6, 10
    //   proc 3: 3, 7, 11
    ilist = dispatcher(0, 12, myid, size, false);
    n = ilist.size();
    assert(n == 3);
    for (int i = 0; i != n; i++) assert(ilist[i] == myid + i * 4);

    // inbalanced non-sequential dispatching
    //   proc 0: 0, 4
    //   proc 1: 1
    //   proc 2: 2
    //   proc 3: 3
    ilist = dispatcher(0, 5, myid, size, false);
    n = ilist.size();
    /* for (auto &id: ilist) */
    /*     printf("myid = %d, id = %u\n", myid, id); */
    if (myid == 0)
    {
        assert(n == 2);
        assert(ilist[0] == 0);
        assert(ilist[1] == 4);
    }
    else
    {
        assert(n == 1);
        assert(ilist[0] == myid);
    }

    // inbalanced sequential dispatching
    //   proc 0: 0, 1
    //   proc 1: 2, 3
    //   proc 2: 4
    //   proc 3: 5
    ilist = dispatcher(0, 6, myid, size, true);
    n = ilist.size();
    /* for (auto &id: ilist) */
    /*     printf("myid = %d, id = %u\n", myid, id); */
    if ((myid == 0) || (myid == 1))
    {
        assert(n == 2);
        assert(ilist[0] == myid * 2);
        assert(ilist[1] == myid * 2 + 1);
    }
    else
    {
        assert(n == 1);
        assert(ilist[0] == myid + 2);
    }
}

void test_dispatcher_2d()
{
    const int myid = get_mpi_rank(MPI_COMM_WORLD);
    const int size = get_mpi_size(MPI_COMM_WORLD);
    int n;

    // =====================================
    // double index dispatcher
    // balanced sequential, 1st faster
    //   proc 0: (0, 1), (1, 1)
    //   proc 1: (0, 2), (1, 2)
    //   proc 2: (0, 3), (1, 3)
    //   proc 3: (0, 4), (1, 4)
    auto i2list = dispatcher(0, 2, 1, 5, myid, size, true, true);
    n = i2list.size();
    assert(n == 2);
    for (int i = 0; i != 2; i++)
    {
        assert(i2list[i].first == i);
        assert(i2list[i].second == myid + 1);
    }

    // balanced sequential, 2nd faster
    //   proc 0: (0, 1), (0, 2)
    //   proc 1: (0, 3), (0, 4)
    //   proc 2: (1, 1), (1, 2)
    //   proc 3: (1, 3), (1, 4)
    i2list = dispatcher(0, 2, 1, 5, myid, size, true, false);
    n = i2list.size();
    assert(n == 2);
    for (int i = 0; i != 2; i++)
    {
        assert(i2list[i].first == myid / 2);
        assert(i2list[i].second == (myid % 2) * 2 + i + 1);
    }

    // balanced non-sequential, 1st faster
    //   proc 0: (0, 1), (0, 3)
    //   proc 1: (1, 1), (1, 3)
    //   proc 2: (0, 2), (0, 4)
    //   proc 3: (1, 2), (1, 4)
    i2list = dispatcher(0, 2, 1, 5, myid, size, false, true);
    n = i2list.size();
    assert(n == 2);
    for (int i = 0; i != 2; i++)
    {
        assert(i2list[i].first == myid % 2);
        assert(i2list[i].second == 1 + (myid / 2) + i * 2);
    }
    // balanced non-sequential, 2nd faster
    //   proc 0: (0, 1), (2, 1)
    //   proc 1: (0, 2), (2, 2)
    //   proc 2: (1, 1), (3, 1)
    //   proc 3: (1, 2), (3, 2)
    i2list = dispatcher(0, 4, 1, 3, myid, size, false, false);
    n = i2list.size();
    assert(n == 2);
    for (int i = 0; i != 2; i++)
    {
        assert(i2list[i].first == myid / 2 + i * 2);
        assert(i2list[i].second == myid % 2 + 1);
    }

    // inbalanced sequential, 1st faster
    i2list = dispatcher(0, 3, 1, 3, myid, size, true, true);
    n = i2list.size();
    //   proc 0: (0, 1), (1, 1)
    //   proc 1: (2, 1), (0, 2)
    //   proc 2: (1, 2)
    //   proc 3: (2, 2)
    if ((myid == 0) || (myid == 1))
    {
        assert(n == 2);
        assert(i2list[0].first == myid * 2);
        assert(i2list[0].second == 1);
        assert(i2list[1].first == 1 - myid);
        assert(i2list[1].second == myid + 1);
    }
    else
    {
        assert(n == 1);
        assert(i2list[0].first == myid - 1);
        assert(i2list[0].second == 2);
    }

    // inbalanced sequential, 2nd faster
    i2list = dispatcher(0, 2, 2, 5, myid, size, true, false);
    n = i2list.size();
    //   proc 0: (0, 2), (0, 3)
    //   proc 1: (0, 4), (1, 2)
    //   proc 2: (1, 3)
    //   proc 3: (1, 4)
    if ((myid == 0) || (myid == 1))
    {
        assert(n == 2);
        assert(i2list[0].first == 0);
        assert(i2list[0].second == (myid + 1) * 2);
        assert(i2list[1].first == myid);
        assert(i2list[1].second == 3 - myid);
    }
    else
    {
        assert(n == 1);
        assert(i2list[0].first == 1);
        assert(i2list[0].second == myid + 1);
    }

    // inbalanced non-sequential, 1st faster
    i2list = dispatcher(-1, 2, 1, 3, myid, size, false, true);
    n = i2list.size();
    //   proc 0: (-1, 1), (0, 2)
    //   proc 1: ( 0, 1), (1, 2)
    //   proc 2: ( 1, 1)
    //   proc 3: (-1, 2)
    if ((myid == 0) || (myid == 1))
    {
        printf("myid %d: item 0: (%d %d) item 1 (%d %d)\n", myid, i2list[0].first, i2list[0].second,
               i2list[1].first, i2list[1].second);
        assert(n == 2);
        assert(i2list[0].first == myid - 1);
        assert(i2list[0].second == 1);
        assert(i2list[1].first == myid);
        assert(i2list[1].second == 2);
    }
    else
    {
        printf("myid %d: item 0: (%d %d)\n", myid, i2list[0].first, i2list[0].second);
        assert(n == 1);
        assert(i2list[0].first == 5 - 2 * myid);
        assert(i2list[0].second == myid - 1);
    }

    // inbalanced non-sequential, 2nd faster
    i2list = dispatcher(0, 3, -2, 0, myid, size, false, false);
    n = i2list.size();
    //   proc 0: (0, -2), (2, -2)
    //   proc 1: (0, -1), (2, -1)
    //   proc 2: (1, -2)
    //   proc 3: (1, -1)
    if ((myid == 0) || (myid == 1))
    {
        printf("myid %d: item 0: (%d %d) item 1 (%d %d)\n", myid, i2list[0].first, i2list[0].second,
               i2list[1].first, i2list[1].second);
        assert(n == 2);
        assert(i2list[0].first == 0);
        assert(i2list[0].second == myid - 2);
        assert(i2list[1].first == 2);
        assert(i2list[1].second == myid - 2);
    }
    else
    {
        printf("myid %d: item 0: (%d %d)\n", myid, i2list[0].first, i2list[0].second);
        assert(n == 1);
        assert(i2list[0].first == 1);
        assert(i2list[0].second == myid - 4);
    }
}

void test_dispatcher_1d_balanced()
{
    const int myid = get_mpi_rank(MPI_COMM_WORLD);

    const std::vector<int> weights({1, 2, 3, 6});
    const std::vector<int> counts_ref({6, 3, 2, 1});
    const std::vector<int> starts_ref({0, 6, 9, 11});

    auto ilist = dispatcher_balanced(0, 12, weights[myid], true, MPI_COMM_WORLD);
    int n = ilist.size();
    assert(n == counts_ref[myid]);
    for (int i = 0; i != n; i++) assert(ilist[i] == starts_ref[myid] + i);

    const std::vector<std::vector<int>> ilist_cyclic_ref(
        {{0, 4, 7, 9, 10, 11}, {1, 5, 8}, {2, 6}, {3}});
    ilist = dispatcher_balanced(0, 12, weights[myid], false, MPI_COMM_WORLD);
    assert(equal_vector(ilist, ilist_cyclic_ref[myid]));

    const std::vector<int> weights_2proc({2, 3});
    auto ilist0 = dispatcher_balanced(0, 5, weights_2proc, 0, true);
    auto ilist1 = dispatcher_balanced(0, 5, weights_2proc, 1, true);
    assert(equal_vector(ilist0, std::vector<int>({0, 1, 2})));
    assert(equal_vector(ilist1, std::vector<int>({3, 4})));

    ilist0 = dispatcher_balanced(0, 5, weights_2proc, 0, false);
    ilist1 = dispatcher_balanced(0, 5, weights_2proc, 1, false);
    assert(equal_vector(ilist0, std::vector<int>({0, 2, 4})));
    assert(equal_vector(ilist1, std::vector<int>({1, 3})));

    MPI_Comm comm_pair;
    MPI_Comm_split(MPI_COMM_WORLD, myid / 2, myid, &comm_pair);
    const int pair_myid = get_mpi_rank(comm_pair);
    auto ilist_pair = dispatcher_balanced(0, 5, weights_2proc[pair_myid], true, comm_pair);
    if (pair_myid == 0)
        assert(equal_vector(ilist_pair, std::vector<int>({0, 1, 2})));
    else
        assert(equal_vector(ilist_pair, std::vector<int>({3, 4})));
    MPI_Comm_free(&comm_pair);
}

void test_handler_allreduce()
{
    MpiCommHandler comm_h(MPI_COMM_WORLD, true);
    std::vector<int> v_this(comm_h.nprocs, 0);
    v_this[comm_h.myid] = comm_h.myid + 1;
    comm_h.allreduce(MPI_IN_PLACE, v_this.data(), comm_h.nprocs, MPI_MAX);
    const std::vector<int> v_ref({1, 2, 3, 4});
    assert(equal_array(comm_h.nprocs, v_this.data(), v_ref.data()));
}

void test_handler_bcast()
{
    MpiCommHandler comm_h(MPI_COMM_WORLD, true);
    int v = comm_h.myid;
    int root = 2;
    comm_h.bcast(&v, 1, root);
    assert(v == root);
}

void test_find_mpi_owner_rank()
{
    const int myid = get_mpi_rank(MPI_COMM_WORLD);

    int owner = find_mpi_owner_rank(myid == 2, MPI_COMM_WORLD);
    assert(owner == 2);

    owner = find_mpi_owner_rank(myid == 1 || myid == 3, MPI_COMM_WORLD);
    assert(owner == 1);

    owner = find_mpi_owner_rank(false, MPI_COMM_WORLD);
    assert(owner == -1);
}

int main(int argc, char *argv[])
{
    int provided;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided);

    size_global = get_mpi_size(MPI_COMM_WORLD);

    if (size_global != 4) throw std::runtime_error("test imposes 4 MPI processes");

    myid_global = get_mpi_rank(MPI_COMM_WORLD);

    test_dispatcher_1d();
    test_dispatcher_2d();
    test_dispatcher_1d_balanced();
    test_handler_allreduce();
    test_handler_bcast();
    test_find_mpi_owner_rank();

    MPI_Finalize();

    return 0;
}
