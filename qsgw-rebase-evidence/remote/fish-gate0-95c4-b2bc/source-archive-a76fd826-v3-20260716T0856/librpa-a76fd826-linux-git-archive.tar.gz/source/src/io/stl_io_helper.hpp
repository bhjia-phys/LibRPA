#pragma once
#include <array>
#include <map>
#include <ostream>
#include <set>
#include <vector>
#include <utility>
#include <tuple>

namespace librpa_int {

//! Print a set of objects
template <typename T>
std::ostream& operator<<(std::ostream& os, const std::set<T> &set_objs)
{
    os << "[";
    if (!set_objs.empty())
    {
        auto pobj = set_objs.cbegin();
        for (; pobj != std::prev(set_objs.cend()); pobj++)
            os << *pobj << ",";
        os << *pobj;
    }
    os << "](s" << set_objs.size() << ")";
    return os;
}

//! Print a vector of objects
template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T> &vector_objs)
{
    os << "[";
    if (!vector_objs.empty())
    {
        auto pobj = vector_objs.cbegin();
        for (; pobj != std::prev(vector_objs.cend()); pobj++)
            os << *pobj << ",";
        os << *pobj;
    }
    os << "](v" << vector_objs.size() << ")";
    return os;
}

//! Print a pair of objects
template <typename T1, typename T2>
std::ostream& operator<<(std::ostream& os, const std::pair<T1, T2> &pair_objs)
{
    os << "{" << pair_objs.first << "," << pair_objs.second << "}";
    return os;
}

//! Print a tuple of objects
template <typename... T>
std::ostream& operator<<(std::ostream& os, const std::tuple<T...> &tuple_objs)
{
    os << "{";
    if constexpr (sizeof...(T) > 0)
    {
        std::apply([&os](const auto& first, const auto&... rest) {
            os << first;
            ((os << "," << rest), ...);
        }, tuple_objs);
    }
    os << "}";
    return os;
}

//! Print an array containing N objects
template <typename T, size_t N>
std::ostream& operator<<(std::ostream& os, const std::array<T, N> &arr_objs)
{
    os << "[";
    for (size_t i = 0; i < N - 1; i++)
        os << arr_objs[i] << ",";
    os << arr_objs[N-1] << "](a" << N << ")";
    return os;
}

//! Print a map
template <typename Tkey, typename Tval>
std::ostream& operator<<(std::ostream& os, const std::map<Tkey, Tval> &map_objs)
{
    os << "{";
    for (const auto& kv: map_objs)
    {
        os << "\"" << kv.first << "\":\"" << kv.second << "\"\n";
    }
    os << "}";
    return os;
}

//! Print a map
template <typename Tkey, typename Tval, typename Hash>
std::ostream& operator<<(std::ostream& os, const std::unordered_map<Tkey, Tval, Hash> &map_objs)
{
    os << "{";
    for (const auto& kv: map_objs)
    {
        os << "\"" << kv.first << "\":\"" << kv.second << "\"\n";
    }
    os << "}";
    return os;
}

//! Print a the keys of a nested map
template <typename Tkey1, typename Tkey2, typename Tval>
void print_keys(std::ostream& os, const std::map<Tkey1, std::map<Tkey2, Tval>> &nested_map)
{
    os << "{";
    for (const auto& k1k2v: nested_map)
        for (const auto& k2v: k1k2v.second)
            os << k1k2v.first << " " << k2v.first << "\n";
    os << "}";
}

//! Print a the keys of a nested map
template <typename Tkey1, typename Tkey2, typename Tkey3, typename Tval>
void print_keys(std::ostream& os, const std::map<Tkey1, std::map<Tkey2, std::map<Tkey3, Tval>>> &nested_map)
{
    os << "{";
    for (const auto& k1k2k3v: nested_map)
        for (const auto& k2k3v: k1k2k3v.second)
            for (const auto& k3v: k2k3v.second)
                os << k1k2k3v.first << " " << k2k3v.first << " " << k3v.first << "\n";
    os << "}";
}

//! Print a the keys of a nested map
template <typename Tkey1, typename Tkey2, typename Tkey3, typename Tkey4, typename Tval>
void print_keys(std::ostream& os, const std::map<Tkey1, std::map<Tkey2, std::map<Tkey3, std::map<Tkey4, Tval>>>> &nested_map)
{
    os << "{";
    for (const auto& [k1, k2k3k4v]: nested_map)
        for (const auto& [k2, k3k4v]: k2k3k4v)
            for (const auto& [k3, k4v]: k3k4v)
                for (const auto& [k4, _]: k4v)
                    os << k1 << " " << k2 << " " << k3 << " " << k4 << "\n";
    os << "}";
}

//! Get total number of elements
template <typename Tkey1, typename Tkey2, typename Tval>
int get_num_keys(const std::map<Tkey1, std::map<Tkey2, Tval>> &nested_map)
{
    int nkeys = 0;
    for (const auto& [_, k2v]: nested_map)
        nkeys += k2v.size();
    return nkeys;
}

//! Get total number of elements
template <typename Tkey1, typename Tkey2, typename Tkey3, typename Tval>
int get_num_keys(const std::map<Tkey1, std::map<Tkey2, std::map<Tkey3, Tval>>> &nested_map)
{
    int nkeys = 0;
    for (const auto& [_, k2k3v]: nested_map)
        for (const auto& [_, k3v]: k2k3v)
            nkeys += k3v.size();
    return nkeys;
}

}
