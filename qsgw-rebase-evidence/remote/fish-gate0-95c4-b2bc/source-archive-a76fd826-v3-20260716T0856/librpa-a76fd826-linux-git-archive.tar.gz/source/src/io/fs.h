#pragma once
#include <string>
#include <vector>

namespace librpa_int
{

std::string path_as_directory(const std::string &path);

std::string parent_path(const std::string &file_path);

std::string base_name(const std::string &file_path);

bool is_absolute_path(const std::string &file_path);

std::string join_path(const std::string &dir_path, const std::string &file_name);

bool file_exists(const std::string &file_path);

bool is_readable_file(const std::string &file_path);

void require_readable_file(const std::string &file_path);

std::vector<std::string> discover_files(const std::string &dir_path,
                                        const std::string &prefix,
                                        const std::string &suffix);

std::vector<std::string> discover_files_with_prefix(const std::string &dir_path,
                                                    const std::string &prefix);

std::vector<std::string> discover_files_with_suffix(const std::string &dir_path,
                                                    const std::string &suffix);

bool path_exists(const char *path_cstr);

/*!
 * @brief Create directory and its parent directories if necessary.
 *
 * If the directory exists already, the function returns silently.
 * Need to barrier around this function if processes other than root process
 * wants to write files under the directory after creation.
 *
 * @param[in]  dname         Name of the directory to create
 * @param[in]  root_process  Process filter.
 *                           Only the processes that parses 0 to root_process will create the target directory.
 */
void create_directories(const char *dname, int root_process);

}
