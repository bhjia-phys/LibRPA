//==========================================================
// AUTHOR: Lixin He, Mohan Chen
// LAST UPDATE : 2009-03-24 add operator == and !=
//==========================================================
#ifndef MatriX3_H
#define MatriX3_H

#include <array>

#include "vector3.h"

namespace librpa_int {

class Matrix3
{
public:
	static const Matrix3 IDENTITY;
	static const Matrix3 NEGATIVE;
	/* data */
public:
	// element eij:i_column,j_row
	double e11, e12, e13, e21, e22, e23, e31, e32, e33;

	/* Constructors and destructor */
	Matrix3(const double &r11 = 1,const double &r12 = 0,const double &r13 = 0,
	        const double &r21 = 0,const double &r22 = 1,const double &r23 = 0,
	        const double &r31 = 0,const double &r32 = 0,const double &r33 = 1);
	Matrix3(const std::array<double, 9> &a)
	: e11(a[0]), e12(a[1]), e13(a[2]),
		e21(a[3]), e22(a[4]), e23(a[5]),
		e31(a[6]), e32(a[7]), e33(a[8]) {};

	void Reset(void);
	void Identity(void);
	inline double Det(void) const
	{
		return e11 * e22 * e33 - e11 * e32 * e23 +
				e21 * e32 * e13 - e21 * e12 * e33 +
				e31 * e12 * e23 - e31 * e22 * e13;
    }
	Matrix3	Transpose(void) const ;
	Matrix3	Inverse(void) const ;

	Matrix3& operator=(const Matrix3 &m);
	Matrix3& operator+=(const Matrix3 &m);
	Matrix3& operator-=(const Matrix3 &m);
	Matrix3& operator*=(const double &s);
	Matrix3& operator/=(const double &s);

	void print(int width = 10, double eps = 1e-14) const;
};

Matrix3 operator +(const Matrix3 &m1, const Matrix3 &m2);	//m1+m2
Matrix3 operator -(const Matrix3 &m1, const Matrix3 &m2);	//m1-m2
Matrix3 operator /(const Matrix3 &m,const double &s);		//m/s
Matrix3 operator *(const Matrix3 &m1,const  Matrix3 &m2);	//m1*m2
Matrix3 operator *(const Matrix3 &m,const double &s);		//m*s
Matrix3 operator *(double &s, const Matrix3 &m);		//s*m
template<typename T> Vector3<double> operator *(const Matrix3 &m, const Vector3<T> &u);	//m*u				// Peize Lin change Vector3<T> 2017-01-10
template<typename T> Vector3<double> operator *(const Vector3<T> &u, const Matrix3 &m);	//u*m				// Peize Lin change Vector3<T> 2017-01-10

inline bool is_same_matrix(const Matrix3 &m1, const Matrix3 &m2, double tol = 1e-10)
{
	return std::abs(m1.e11 - m2.e11) < tol &&
		std::abs(m1.e12 - m2.e12) < tol &&
		std::abs(m1.e13 - m2.e13) < tol &&
		std::abs(m1.e21 - m2.e21) < tol &&
		std::abs(m1.e22 - m2.e22) < tol &&
		std::abs(m1.e23 - m2.e23) < tol &&
		std::abs(m1.e31 - m2.e31) < tol &&
		std::abs(m1.e32 - m2.e32) < tol &&
		std::abs(m1.e33 - m2.e33) < tol;
}

//whether m1 == m2
inline bool operator ==(const Matrix3 &m1, const Matrix3 &m2)
{
	if(m1.e11 == m2.e11 &&
	   m1.e12 == m2.e12 &&
	   m1.e13 == m2.e13 &&
	   m1.e21 == m2.e21 &&
	   m1.e22 == m2.e22 &&
	   m1.e23 == m2.e23 &&
	   m1.e31 == m2.e31 &&
	   m1.e32 == m2.e32 &&
	   m1.e33 == m2.e33)
	{
		return true;
	}
	return false;
}

inline bool operator!=(const Matrix3 &m1, const Matrix3 &m2)
{
	return !(m1 == m2);
}  // whethor m1 != m2

std::ostream & operator <<( std::ostream &os, const Matrix3 &m);

//m*u
template<typename T>
Vector3<double> operator *(const Matrix3 &m, const Vector3<T> &u)
{
	return Vector3<double>(m.e11*u.x + m.e12*u.y + m.e13*u.z,
	                       m.e21*u.x + m.e22*u.y + m.e23*u.z,
	                       m.e31*u.x + m.e32*u.y + m.e33*u.z);
}

//u*m
template<typename T>
Vector3<double> operator *(const Vector3<T> &u, const Matrix3 &m)
{
	return Vector3<double>(u.x*m.e11 + u.y*m.e21 + u.z*m.e31,
	                       u.x*m.e12 + u.y*m.e22 + u.z*m.e32,
	                       u.x*m.e13 + u.y*m.e23 + u.z*m.e33);
}

}

#endif // MATRIX3_H
